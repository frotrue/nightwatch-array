extends SceneTree
const Session = preload("res://tests/support/economy_session.gd")
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	var args := OS.get_cmdline_user_args()
	var config: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(args[0]))
	var folder: String = args[1]
	DirAccess.make_dir_recursive_absolute(folder)
	var session := Session.new()
	await session.setup(self, config)
	if args.size() > 2:
		var restored: Dictionary = await session.load_checkpoint(args[2], "branch", config)
		if not restored.ok:
			push_error(str(restored)); quit(1); return
	var milestones := [15, 40, 80, 95]
	while session.stop_reason().is_empty():
		await session.auto_purchase()
		for count in milestones.duplicate():
			if session.game.progression.purchased_nodes.size() >= count:
				var result: Dictionary = session.save_checkpoint(folder.path_join("checkpoint-%d.json" % count))
				if not result.ok: push_error(str(result)); quit(1); return
				milestones.erase(count)
		if not session.stop_reason().is_empty(): break
		await session.act({"action":"next_round", "revision":session.revision})
		if session.rounds.size() % 10 == 0:
			print("PACE round=%d base=%d outer=%d income=%.0f" % [session.rounds.size(),session.game.progression.purchased_nodes.size(),session.game.deep_sky.state.research_ids.size(),session.rounds.back().income])
	await session.auto_purchase()
	var report: Dictionary = session.report()
	var file := FileAccess.open(folder.path_join("report.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"\t")); file.close()
	print("TUNING_RESULT rounds=%d base=%d outer=%d active=%.0f max=%d stop=%s ledger=%.0f" % [session.rounds.size(),report.base_research,report.extension_research,report.active_seconds,report.maximum_purchase_batch,report.stop_reason,report.ledger_error])
	await session.dispose()
	quit(0)
