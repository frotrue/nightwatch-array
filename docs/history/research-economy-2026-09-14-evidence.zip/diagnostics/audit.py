import ast
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parents[2]
data = root / 'build/economy-tuning'
def nodes(path):
    s = path.read_text(encoding='utf-8')
    s = s.split('const UPGRADE_NODES: Array[Dictionary] = ',1)[1].split('\n]',1)[0]+ '\n]'
    return ast.literal_eval(re.sub(r'\b(false|true)\b', lambda m: m[0].title(), s))
old = nodes(data / 'game_balance.gd')
new = nodes(root / 'scripts/game_balance.gd')
assert len(old) == len(new) == 95
allowed = {'cost','description','runtime_parameters','effect_contract','icon'}
reward_ids = {'taurus_full_gallop','double_star_resolution','perseid_outburst','echo_delay_line','galaxy_imaging','fireball_tail','draco_apotheosis'}
changes = []
for a,b in zip(old,new):
    changed = {k for k in a.keys()|b.keys() if a.get(k)!=b.get(k)}
    assert changed <= allowed, (a['id'],changed)
    assert not (changed-{'cost'}) or a['id'] in reward_ids
    if 'cost' in changed:
        assert len(str(b['cost']).rstrip('0')) <= 2
        changes.append({'id':a['id'],'branch':a['branch'],'old_price':a['cost'],'new_price':b['cost']})
before = (data/'expansion_data.gd').read_text(encoding='utf-8')
after = (root/'scripts/expansion_data.gd').read_text(encoding='utf-8')
pattern = r'("cost":\s*)[0-9]+'
assert re.sub(pattern,r'\1PRICE',before)==re.sub(pattern,r'\1PRICE',after)
old_prices = [int(m[1]) for m in re.finditer(r'"cost":\s*([0-9]+)',before)]
new_prices = [int(m[1]) for m in re.finditer(r'"cost":\s*([0-9]+)',after)]
assert len(old_prices)==len(new_prices)==55
assert all(len(str(n).rstrip('0'))<=2 for n in new_prices if n)
(data/'price-changes.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8')
print(f'SCOPE_PASS: 95 base + 55 outer IDs, graph and non-money effects preserved; clean prices; base changes={len(changes)}, outer changes={sum(a!=b for a,b in zip(old_prices,new_prices))}, reward changes={len(reward_ids)}; base_total={sum(n["cost"] for n in new)}, outer_total={sum(new_prices)}')
