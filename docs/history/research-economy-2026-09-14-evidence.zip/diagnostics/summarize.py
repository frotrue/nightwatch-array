import collections
import json
from pathlib import Path

root = Path(__file__).parent
for path in sorted(root.glob('*/report.json')):
    r = json.loads(path.read_text(encoding='utf-8'))
    rounds = r['rounds']
    histogram = collections.Counter(len(row['purchases']) for row in rounds)
    groups = {name: [] for name in ['opening', 'middle', 'base_end', 'outer']}
    count = 0
    for row in rounds:
        group = 'opening' if count < 25 else 'middle' if count < 75 else 'base_end' if count < 95 else 'outer'
        groups[group].append(len(row['purchases']))
        count += len(row['purchases'])
    result = {'run': path.parent.name, 'research': [r['base_research'], r['extension_research']], 'rounds': len(rounds), 'seconds': r['active_seconds'], 'histogram': dict(sorted(histogram.items())), 'one_two_percent': round(100 * (histogram[1] + histogram[2]) / len(rounds), 1), 'three_plus_percent': round(100 * sum(v for k,v in histogram.items() if k>=3) / len(rounds), 1), 'ledger_error': r['ledger_error'], 'groups': {k: {'rounds':len(v), 'purchases':sum(v), 'average':round(sum(v)/len(v),2), 'zero':v.count(0)} for k,v in groups.items() if v}}
    print(json.dumps(result))
